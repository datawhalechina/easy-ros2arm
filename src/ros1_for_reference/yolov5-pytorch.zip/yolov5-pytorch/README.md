***************** [一]文件夹结构 ***************** 
官网: https://github.com/ultralytics/yolov5
<----------------------------了解--------------------------------->

data/garbage/train/images存放数据集的图片
data/garbage/train/labels存放数据集的标签 
标签格式:  label  x y w h 
x,y,w,h的值是将图像长和高按[0:1]所在的位置

文件夹 inference/images测试图片路径
文件夹 inference/output测试输出路径
data/image存放原图像(要识别的目标图像)
data/texture存放背景图像(需要多一些)
data/Get_garbageData.py自动生成对应的数据集(需要多一些)

weights文件夹是用来存放权重文件(预训练模型)的,
如需最新版或其他模型文件请到官网自行下载
https://github.com/ultralytics/yolov5/releases

runs训练输出位置
runs/exp/weights由两个文件best.pt是最好的训练模型,如果只有一个就是它啦
在runs/exp文件里有验证图片,训练完一个epoch就去看看,验证图片是否正确,
如果不正确就赶紧调整,不然训练完所有再调整就得重新训练.
/runs/exp1/results.txt训练的日志信息

***************** [二]环境要求 ***************** 
Cython
matplotlib>=3.2.2
numpy>=1.18.5
opencv-python>=4.1.2
pillow
PyYAML>=5.3
scipy>=1.4.1
tensorboard>=2.2
torch>=1.6.0
torchvision>=0.7.0
tqdm>=4.41.0
安装示例: pip install Cython

***************** [三]自定义训练数据集  ***************** 
<--------------------------- 1 ---------------------------------->
制作yaml文件
例如garbage.yaml:
train: ./data/garbage/train/images/       <--------训练集图片路径
val: ./data/garbage/train/images/         <--------验证集图片路径(也可与训练集分开)

nc: 16                                    <--------类别数量
names: ["Zip_top_can", "Apple_core"...]   <--------类别名称
<--------------------------- 2 ---------------------------------->
修改train.py
第381行:预训练权重,
第383行:自定义训练文件,
第385行:自定义训练epochs,训练多少轮.
其他地方根据需求,自己调整,不懂不要改.
<--------------------------- 3 ---------------------------------->
修改models/yolov5s.yaml文件第二行   <---------用哪个权重文件修改对应的yaml文件
nc: 16  # number of classes


***************** [四]使用流程  *****************
0.按照上面的流程配置完毕后
1.在yolov5-pytorch/garbage/texture该路径下,多多填充一些背景图片([要多一些]).
2.运行Get_garbageData.py文件获得数据集(第134行可修改生成数据集的数量[要多一些]).
3.运行train.py文件开始训练
4.运行detect.py进行预测(第134行可修改使用预测模型的路径)



